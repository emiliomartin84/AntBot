/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */



import core.GameStateInterface;
import core.Node;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Emilio
 */
public class CollectorE extends AntE {


    private double edibleGhost;


    private double points;
    private int empty;
    private int ghost;
    public double getEdibleGhost() {
        return edibleGhost;
    }

    public void setEdibleGhost(double edibleGhost) {
        this.edibleGhost = edibleGhost;
    }

    public int getPill() {
        return pill;
    }

    public void setPill(int pill) {
        this.pill = pill;
    }

    public int getPowerpill() {
        return powerpill;
    }

    public void setPowerpill(int powerpill) {
        this.powerpill = powerpill;
    }

    public double getPoints() {
        return points;
    }

    public void setPoints(double points) {
        this.points = points;
    }

    public int getEmpty() {
        return empty;
    }

    public void setEmpty(int empty) {
        this.empty = empty;
    }

    public int getGhost() {
        return ghost;
    }

    public void setGhost(int ghost) {
        this.ghost = ghost;
    }




    public CollectorE(PheromoneE[][] phero, Node initial,
                      int distPac,
                      Random rand,strabon.di.uoa.gr
                      int max_dist,
                      double q0,
                      double edibleGhost,
                      double fac,
                      GameStateInterface gs,
                      double phi,
                      double alfa)
	{
            super.pheromone = phero;
			super.gs = gs;
			super.last = initial;
			super.distance = distPac;
			super.nodes = new ArrayList<SimpleNodeE>();
			super.r = rand;
			super.MAX_DISTANCE = max_dist;
			//MAX_POINT = max_point;
			super.Q0 = q0;
			super.FACTOR_SEC = fac;
            super.alfa = alfa;
            super.phi = phi;
			this.edibleGhost = edibleGhost;
            this.pill = 0;
            this.powerpill=0;
            this.points = 0;
            this.empty = 0;
            this.ghost = 0;

	}
    public void execute( GameStateInterface gs)
    {

        this.nodes.add(new SimpleNodeE(gs.getPacman().current,0,0,0,false,false,gs));
        while (!stopCondition(gs))
        {
            move( gs, 0);
        }
        if (this.points == 0)
            this.dead = true;
    }

    public void move(GameStateInterface gs, int i)
    {
        Node nodeUpdate = gs.getMaze().getNode(last.x,last.y);
        collectFood(nodeUpdate, gs);
        int peligrosidad = 0;
        boolean edibleGhost = this.existsEdibleGhost(nodeUpdate, gs,powerpill);
        this.nodes.add(new SimpleNodeE(last,super.calculateConnectivity(last), distance, peligrosidad, dead, edibleGhost,this.points,false,gs));
        this.pheromoneEvaporation(last);
        Node aux = chooseNext(nodeUpdate, i);
        if (aux == null)//No ghost but Exist a loop
        {
            this.loop = true;
        }
        else //No ghost
        {
            this.last = aux;
        }
        this.distance += 1;
    }

    public Node chooseNextBest(Node n, int ind)
    {
        Node next = null;

        ArrayList<Node> adjacents =  possibleDir(n);
        ArrayList <Double> probability = new ArrayList <Double>();


        int best = 0;
        for (int i = 0; i < adjacents.size(); i++)
        {
            SimpleNodeE snode = new SimpleNodeE(adjacents.get(i), calculateConnectivity(adjacents.get(i)), distance, 0, false, false,gs);
            probability.add(computeRuleTranstion(adjacents.get(i), ind));
            if (computeRuleTranstion(adjacents.get(i), ind) >=
                    computeRuleTranstion(adjacents.get(best), ind))
            {
                best = i;
                next = adjacents.get(best);
            }
        }
        return next;
    }



    public Node chooseNext(Node n, int ind)
    {
        Node next = null;
        ArrayList<Node> adjacents = possibleDir(n);
        if (adjacents.size() == 1)
            next = adjacents.get(0);
        else
        {
            ArrayList <Double> probability = new ArrayList <Double>();

            double Q = r.nextDouble();

            if (Q > Q0)
                return (chooseNextBest(n, ind));

            double sum = 0;
            for (int i = 0; i < adjacents.size(); i++)
            {
                SimpleNodeE snode = new SimpleNodeE(adjacents.get(i), calculateConnectivity(adjacents.get(i)), distance, 0, false, false,gs);
                probability.add(computeRuleTranstion(adjacents.get(i), ind));
                sum += computeRuleTranstion(adjacents.get(i), ind);
            }


            for (int i = 0; i < probability.size(); i++)
            {
                double aux = probability.get(i);
                probability.set(i, aux/sum) ;
            }

            double ran = r.nextDouble();
            //Select the next Node
            sum = 0;
            for (int i = 0; i < probability.size(); i++)
            {
                sum += probability.get(i);
                if (sum > ran)
                {
                    next = adjacents.get(i);
                    break;
                }
            }
        }
        return next;
    }

    public double heuristic(Node n)
    {
        double res = 0;
         double pillFactor = gs.getPills().cardinality() / gs.getPills().size();
        if (n.pillIndex != -1 && gs.getPills().get(n.pillIndex))
            res += 1/pillFactor;
        res += 1/(1+closestEdibleGhost(n,gs));
        return res;
    }
    public double computeRuleTranstion(Node n, int ind)
    {
        double deseability = 0;
        try{
        if(pheromone[n.x][n.y]==null)
            System.out.print("");
        deseability += pheromone[n.x][n.y].getValue()[ind];
        deseability *= (1+heuristic(n));
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println("erro");
        }
        return deseability;
    }
    public void pheromoneEvaporation(Node node)
    {
        //PHEROMONE 0 --> FOOD
        double Va = pheromone[node.x][node.y].getValue()[0];
        double Vi = 1;
        pheromone[node.x][node.y].getValue()[0] = (1-this.phi)*Va + phi*(Vi);

    }
    public void update(GameStateInterface gs)
    {
        for (int j = 0; j < this.nodes.size(); j++)
        {
            SimpleNodeE s = this.nodes.get(j);
            Node n = gs.getMaze().getNode(s.getX(),s.getY());

            double val = pheromone[n.x][n.y].getValue()[0];
            pheromone[n.x][n.y].getValue()[0] = (1 - alfa) *val + this.points* alfa;
        }
    }
    public void collectFood(Node node, GameStateInterface gameState)
    {
        double pillsLeft = gameState.getPills().cardinality() - this.pill;

        double pillFactor = pillsLeft / (double) gameState.getMaze().getPills().size();
        if (node.pillIndex!= -1 && gameState.getPills().get(node.pillIndex))
        {
            int empty = 0;
            for (int i = 0; i < node.adj.size(); i++)
                if (node.adj.get(i).pillIndex != -1 &&
                         !gameState.getPills().get(node.adj.get(i).pillIndex))
                    empty++;
            this.points += 1 / (pillFactor); //Strategy 3

            this.pill++;
        }
        else if (node.powerIndex!= -1 && gameState.getPowers().get(node.powerIndex))
        {
            this.powerpill++;
        }
        else
        {
            this.empty += 1;
        }
        if(existsEdibleGhost(node,gameState,powerpill))
        {
            this.ghost++;
            this.points += this.edibleGhost/pillFactor;

        }
    }

    private boolean stopCondition(GameStateInterface gameState)
    {
        return (
                this.distance >= this.MAX_DISTANCE ||
                this.loop ||
                this.pill == gs.getPills().cardinality()
                );
    }
}
