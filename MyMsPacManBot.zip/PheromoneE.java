

/**
 * Created by IntelliJ IDEA.
 * User: emilio
 * Date: 14/04/11
 * Time: 17:36
 * To change this template use File | Settings | File Templates.
 */
public class PheromoneE {
    private double [] value;
    private int x;
    private int y;


    public double[] getValue() {
        return value;
    }

    public void setValue(double[] value) {
        this.value = value;
    }

    private int initValue;

    public PheromoneE(int x, int y, int dim, int initValue)
    {
        setValue(new double[dim]);
        this.setX(x);
        this.setY(y);
        this.setInitValue(initValue);
        initValues();
    }

     public void initValues()
     {
         for(int i=0;i< getValue().length;i++)
             getValue()[i]= getInitValue();
     }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getInitValue() {
        return initValue;
    }

    public void setInitValue(int initValue) {
        this.initValue = initValue;
    }
}
