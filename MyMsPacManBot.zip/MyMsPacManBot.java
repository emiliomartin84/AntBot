/*

 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Emilio Martin
 */

import competition.MsPacManController;
import core.Constants;
import core.GameStateInterface;
import core.Ghosts;
import core.Node;
import core.maze.MazeInterface;
import core.utilities.Utilities;
import core.visuals.GameStateView;
import core.visuals.JEasyFrame;

import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Vector;

@SuppressWarnings("unchecked")
public class MyMsPacManBot implements MsPacManController, Constants {


    private boolean debugA = false;
    private boolean debugC = false;
    private boolean visual = false;
    private boolean rules = false;

    int lives;
    int currentLevel =-1;
    Color cBectC = new Color (0, 255,0,25);
    Color cBectA = new Color (255,0,0,25);
    private int aDead = 0;
    private int cDead = 0;
    private int bestC = 0;
    private int bestA = 0;
    private boolean allDeadAvoidance = false;
    private boolean allDeadCollecter = false;
    Vector<CollectorE> antsC;
    Vector<AvoidanceE> antsA;
    private Random random;
    private List<Object> backup;
    private int maxAnts = 15;
    private double edible_ghost = 70;
    private int MIN_DISTANCE = 35;
    private double phi0 = 0.5;
    private double phi1 = 0.5;
    private double alfa0 = 0.5;
    private double alfa1 = 0.5;
    private double FACT_SEC_T0 = 0.0;
    private double FACT_SEC_T1 = 0.0;
    private double q0_T0 = 0.7;
    private double q0_T1 = 0.95;
    private int MAX_DISTANCE_T0 = 100;
    private int MAX_DISTANCE_T1 = 100;
    private  double PORC = 50;

    private  PheromoneE[][] pheromones;
    //To update gui
    private GameStateView gsv;
    private JEasyFrame jframe;
    private boolean eatPills;
    private boolean norules;


    public MyMsPacManBot()
    {
        this.lives = -1;
        random = new Random();
        double [] par = {19.0,79.0,10,0.22,0.7,0.23,0.11,0.0,0.72,0.37,0.69,60.0};
        setParams(par);
        backup();

    }

    public void backup()
    {
        backup = new ArrayList();
        backup.add(maxAnts); //Max ants
        backup.add(edible_ghost);
        backup.add(MIN_DISTANCE);//MIN_DISTANCE
        backup.add(phi0); //Phi0
        backup.add(phi1); //Phi1
        backup.add(alfa0); //alfa0
        backup.add(alfa1); //alfa1
        backup.add(FACT_SEC_T0);
        backup.add(FACT_SEC_T1);
        backup.add(q0_T0);
        backup.add(q0_T1);
        backup.add(PORC);
    }

    public void setParams(double [] params){
        if(params.length==12){
        maxAnts= (int) params[0]; //Max ants
        edible_ghost=params[1];
        MIN_DISTANCE= (int) params[2];//MIN_DISTANCE
        phi0=params[3]; //Phi0
        phi1=params[4]; //Phi1
        alfa0=params[5]; //alfa0
        alfa1=params[6]; //alfa1
        FACT_SEC_T0=params[7];
        FACT_SEC_T1=params[8];
        q0_T0=params[9];
        q0_T1=params[10];
        PORC=params[11];
        }else{
            System.out.println("Incorrect number of parameters");
            System.exit(-1);
        }


    }

    public MyMsPacManBot(double[] params) {
        this.lives = -1;
        random = new Random();
        setParams(params);
        backup();
    }

    public void reset()
    {
        MAX_DISTANCE_T0 = 150;
        MAX_DISTANCE_T1 = 150;
        //Max distance of ants avoidance.
        allDeadAvoidance = false;
        allDeadCollecter = false;
        maxAnts = (Integer)backup.get(0);            //Max ants
        edible_ghost = (Double)backup.get(1);       //Edible ghost
        MIN_DISTANCE = (Integer)backup.get(2);       //MIN_DISTANCE
        phi0 = (Double)backup.get(3);            //Phi0
        phi1 = (Double)backup.get(4);            //Phi1
        alfa0 = (Double)backup.get(5);           //ALFA_T0
        alfa1 = (Double)backup.get(6);           //ALFA_T1
        FACT_SEC_T0 = (Double)backup.get(7);     //FACT_SEC_T0
        FACT_SEC_T1 = (Double)backup.get(8);     //FACT_SEC_T1
        q0_T0 = (Double)backup.get(9);           //Q0_T0
        q0_T1 = (Double)backup.get(10);          //Q0_T1
        PORC=(Double)backup.get(11);;
    }


    private void initPheromones( GameStateInterface gs)
    {

        Node [][] na =  gs.getMaze().getNode2DArray();
        pheromones = new PheromoneE[na.length][];

        for(int i =0;i<pheromones.length;i++)
        {
            pheromones[i] = new PheromoneE[na[i].length];
            for(int j =0;j<pheromones[i].length;j++){
                Node aux = na[i][j];
                if(aux!=null)
                    pheromones[i][j] = new PheromoneE(aux.x,aux.y,2,1);
            }
        }
    }

    public void eatPills (GameStateInterface gs)
    {
        double pp = 0;
        for(int i =0;i< gs.getMaze().getPowers().size();i++)
        {
            Node n =gs.getMaze().getPowers().get(i);
            if(n.powerIndex!= -1 && gs.getPowers().get(n.powerIndex))
                pp++;
        }
        double facTick = ((double)gs.getTotalGameTicks()-gs.getLevel()*3000)/(double)Constants.limit;
        pp /=4.0;
        double res = pp*facTick;
        if(res > 0.2)
            this.norules = true;
        else
            this.norules = false;
        //System.out.println(res);

    }
    public int getAction(GameStateInterface gs) {

        eatPills(gs);
        if(gs.getLevel()!=currentLevel){
            initPheromones(gs);
            this.currentLevel = gs.getLevel();
        }
        if(lives != gs.getLivesRemaining())
        {
            lives = gs.getLivesRemaining();
            reset();
        }
        Node next=null;
        //gs  = (GameState)gas.copy();
        Node pacNode = gs.getPacman().current;


        if(pacNode.x != 0)
               {

            sendAnt(pacNode,maxAnts,gs);
            updatePheromone(gs);
            updateDistances ();
            if ( !avoid (gs) ) //If Ms. is running away
            {
                SimpleNodeE no;
                if (antsC.get(bestC).getNodes().size() >= 2)
                {
                    no = antsC.get(bestC).getNodes().get(1);
                }
                else
                {
                    no = antsC.get(bestC).getNodes().get(0);
                }
                next = gs.getMaze().getNode(no.getX(), no.getY());
            }else
            {
                SimpleNodeE no;
                if (antsA.get(bestA).getNodes().size() >= 2)
                {
                    no = antsA.get(bestA).getNodes().get(1);
                }
                else
                {
                    no = antsA.get(bestA).getNodes().get(0);
                }
                next = gs.getMaze().getNode(no.getX(), no.getY());

            }
            if (visual)
                paintBest(gs);
            int res = Utilities.getWrappedDirection(pacNode, next, gs.getMaze());//,gs.getMaze());
            return res;

                    }else
            return NEUTRAL;


    }

    private boolean avoid (GameStateInterface gs)
    {
        double aux =                 this.aDead;
        double porc = (aux/ antsA.size()) * 100;
        boolean res = false;
        //System.out.println("PORC "+porc+ "%");

        Node nodePac = gs.getPacman().current;

        res = porc >= PORC;

        for( Ghosts g : gs.getGhosts())
        {
            int distance = gs.getMaze().dist(g.current,nodePac);
            if(distance < MIN_DISTANCE && !g.edible() && !g.returning() && isComming(gs,g,gs.getPacman().current))
                res = true;
        }

        if(allDeadAvoidance)
            res=true;
        //System.out.println("HUYO "+res);
        return res;

    }


    public boolean isComming(GameStateInterface gs,Ghosts g, Node last)
    {
        if(g.previous !=null){
            int distancePrev =  gs.getMaze().dist(g.previous,last);
            int distanceAct = gs.getMaze().dist(g.current,last);
            return distanceAct <= distancePrev;
        }else
            return false;

    }
    private void updateDistances ()
    {
        if (this.allDeadCollecter)
            if(this.MAX_DISTANCE_T0 < 100)
                this.MAX_DISTANCE_T0 = this.MAX_DISTANCE_T0 + 1;
            else
            {
                if (this.MAX_DISTANCE_T0 > 100)
                    this.MAX_DISTANCE_T0 = this.MAX_DISTANCE_T0 - 1;
                else
                    this.MAX_DISTANCE_T0 = this.MAX_DISTANCE_T0 + 1;
            }
        if (this.allDeadAvoidance) //All ants are died
        {
            if (this.MAX_DISTANCE_T1 > 100)
                this.MAX_DISTANCE_T1 = this.MAX_DISTANCE_T1 / 2;
            else if (MAX_DISTANCE_T1 > 50)
                this.MAX_DISTANCE_T1 = this.MAX_DISTANCE_T1 - 1;
        }
        else
        {
            if (this.MAX_DISTANCE_T1 < 50)
                this.MAX_DISTANCE_T1 *= 2;
            else if (MAX_DISTANCE_T1 < 100)
                this.MAX_DISTANCE_T1 += 1;
        }

    }
    private ArrayList <Node> adjacents (Node n, MazeInterface m)
    {
        ArrayList <Node> res = new ArrayList <Node> ();
        int[] dx = {0, 1, 0, -1, 0};
        int[] dy = {-1, 0, 1, 0, 0};
        // then for each proper direction
        for (int i = 0; i < dx.length; i++) {
            if (dx[i] != 0 || dy[i] != 0) {
                Node adj = m.getNode(n.x + dx[i], n.y + dy[i]);
                if (adj != null) res.add(adj);
            }
        }
        return res;
    }
    private void sendAnt(Node initial, int numAnts, GameStateInterface gs)
    {
        antsC = new Vector<CollectorE>();
        antsA = new Vector<AvoidanceE>();
        ArrayList<Node> possible = adjacents(initial,gs.getMaze());
        this.cDead = 0;
        this.aDead = 0;

        for(int i=0;i<numAnts;i++)
        {
            int aux =  (i % possible.size());
            CollectorE c = new CollectorE(this.pheromones,possible.get(aux), 1, random, MAX_DISTANCE_T0, q0_T0, edible_ghost, FACT_SEC_T0, gs, phi0, alfa0);
            c.execute(gs);
            antsC.add(c);
            if (c.dead)
                cDead++;
            AvoidanceE a = new AvoidanceE(this.pheromones,possible.get(aux),1,random,MAX_DISTANCE_T1,gs,q0_T1,FACT_SEC_T1,phi1,alfa1);
            a.execute(gs);
            antsA.add(a);
            if(a.dead)
                aDead++;
        }
        if (aDead == antsA.size())
        {
            this.allDeadAvoidance = true;
        }
        else
            this.allDeadAvoidance = false;

        if (cDead == antsC.size())
        {
            this.allDeadCollecter = true;
        }
        else
            this.allDeadCollecter = false;
    }

    private void  updatePheromone(GameStateInterface gs)
    {
        bestA = 0;
        bestC = 0;
        double pBest = 0;
        //Copy each ant type.
        double[] pel = new double[antsA.size()];
        double [] points = new double [antsC.size()];
        //Avoidance Ants
        for (int i = 0; i < antsA.size(); i++)
        {
            Color c = new Color (random.nextInt(256),
                    random.nextInt(256),
                    random.nextInt(256),
                    125);
            Ghosts ga = antsA.get(i).closestGhost(gs.getPacman().current,gs);
            int closestF = antsA.get(i).closestGhostDistance(gs.getPacman().current,ga,gs);
            for (int j = 0; j < antsA.get(i).getNodes().size(); j++)
            {
                SimpleNodeE s = antsA.get(i).getNodes().get(j);
                double fac = 1.0 / (Math.pow((j + 1),   2) );
                Node n = gs.getMaze().getNode(s.getX(), s.getY());
                double val = pheromones[s.getX()][s.getY()].getValue()[0];
                pel[i] += antsA.get(i).getNodes().get(j).getDistfromghost() * fac + val * FACT_SEC_T1 * fac;
                if (antsA.get(i).getNodes().get(j).getType().toString() == SimpleNodeE.typeOfNode.PowerPill.toString()
                       && numEdibleGhost(gs)==0 && norules ){
                    pel[i] *= 100;
                    ga = antsA.get(i).closestGhost(n,gs);
                    closestF = antsA.get(i).closestGhostDistance(n,ga,gs);
                    double value = agentOverlapDistance+3;
                    if (antsA.get(i).getNodes().get(j).getType().toString() == SimpleNodeE.typeOfNode.PowerPill.toString()
                            && j == 1 && closestF > value                         )
                    {
                        pel[i] = 0;
                        antsA.remove(i);
                        i--;
                        break;
                    }
                }
                if (antsA.get(i).pill == gs.getPills().cardinality())
                {
                    pel[i] *=100000;

                }
            }
            if (debugA)
            {
                System.out.println("Avoid "+pel[i]);

                    for(int j = 0; j < antsA.get(i).getNodes().size(); j++)
                    {
                        SimpleNodeE s = antsA.get(i).getNodes().get(j);
                        Node n = gs.getMaze().getNode(s.getX(), s.getY());
                        n.col = c;

                    }
                this.gsv.repaint();
                        this.jframe.repaint();
                 BufferedReader br = new BufferedReader(new InputStreamReader(System.in) );
                    try {
                        br.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }


            }
        }
        for(int i= 0;i<antsC.size();i++)
        {
            Color c = new Color (0, 255, 0,  20);
            for (int j = 1; j < antsC.get(i).getNodes().size(); j++)
            {

                SimpleNodeE s = antsC.get(i).getNodes().get(j);
                double fac = 0;
                Node n = gs.getMaze().getNode(s.getX(), s.getY());


                if( (antsC.get(i)).getGhost() > 0 )
                    fac = 1.0 / (Math.pow((j + 1), 1));
                else
                    fac = 1.0 / (Math.pow((j + 1), 3));
                double val = pheromones[s.getX()][s.getY()].getValue()[1];
                points[i] += (antsC.get(i)).getNodes().get(j).getPoints() * fac + val * FACT_SEC_T0 * fac; //Points / (float)(antsC[bestC].Distance + antsC[bestC].Empty);
                double aux = 100.0 /(gs.getLevel());
                int cast = (int)Math.round(aux);
                if ( !norules && (antsC.get(i).getNodes().get(j).getType() == SimpleNodeE.typeOfNode.PowerPill.toString())
                        || (norules && antsC.get(i).getNodes().get(j).getType() == SimpleNodeE.typeOfNode.PowerPill.toString() && antsC.get(i).getGhost()<1) )
                {
                    if(antsC.size()>1){
                        points[i] = 0;
                        antsC.remove(i);
                        i--;
                        break;
                    }
                }
                if(rules){
                    if (antsC.get(i).getNodes().get(j).getType() == SimpleNodeE.typeOfNode.PowerPill.toString()  )
                    {
                        points[i] = 0;
                        antsC.remove(i);
                        i--;
                        break;
                    }
                }

            }
            if (debugC)
            {
                System.out.println("Collec "+points[i]+" \tEdible: "+antsC.get(i).getGhost());
                    for(int j = 0; j < antsC.get(i).getNodes().size(); j++)
                    {

                        SimpleNodeE s = antsC.get(i).getNodes().get(j);
                        Node n = gs.getMaze().getNode(s.getX(), s.getY());
                        n.col = c;

                    }
                    this.gsv.repaint();
                        this.jframe.repaint();
                 BufferedReader br = new BufferedReader(new InputStreamReader(System.in) );
                    try {
                        br.readLine();
                    } catch (IOException e) {
                       e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }



            }
        }
        for (int i = 0; i < antsC.size();i++)
        {
            if (points[bestC] < points[i])
                bestC = i;
        }
        //Console.WriteLine();
        if(antsC.size() > 0 )//&& !avoid(gs))
            (antsC.get(bestC)).update(gs);
        if (antsC.size() == 0)
            allDeadCollecter = true;
        bestA = 0;
        for (int i = 0; i < antsA.size(); i++)
        {
            if (!allDeadAvoidance && !antsA.get(i).isDead())
                pel[i] *= 10;
            if (allDeadAvoidance)
                pel[i] = antsA.get(i).distance;
            if (pel[bestA] < pel[i])
                bestA = i;
        }

        if(antsA.size() > 0 )//&& avoid(gs) )
            (antsA.get(bestA)).update(gs);
        if (antsA.size() == 0)
            allDeadCollecter = true;

    }

    public int numEdibleGhost (GameStateInterface gs)
    {
        int res = 0;
        for (  Ghosts g: gs.getGhosts() )
        {
            if (g.edible() && !g.returning() )
            {
                res++;
            }
        }
        return res;
    }

    private void paintBest (GameStateInterface gs)
    {
        if(!avoid(gs))
        {
            for(int j = 0; j < antsC.get(bestC).getNodes().size(); j++)
            {
                SimpleNodeE s = antsC.get(bestC).getNodes().get(j);
                Node n = gs.getMaze().getNode(s.getX(), s.getY());
                n.col = cBectC;
            }
        }
        else
        {
            for(int j = 0; j < antsA.get(bestA).getNodes().size(); j++)
            {
                SimpleNodeE s = antsA.get(bestA).getNodes().get(j);
                Node n = gs.getMaze().getNode(s.getX(), s.getY());
                n.col = cBectA;
            }
        }

    }

    public void setVisual(GameStateView gsv, JEasyFrame fr) {
        //To change body of created methods use File | Settings | File Templates.
        this.gsv = gsv;
        this.jframe = fr;
    }
}
