import core.GameStateInterface;
import core.Ghosts;
import core.Node;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by IntelliJ IDEA.
 * User: emilio
 * Date: 13/05/11
 * Time: 15:15
 * To change this template use File | Settings | File Templates.
 */
public class CollectorG extends Ant{

    private boolean edibleGhost;


       private double points;
       private int empty;
       private int ghost;
    private boolean middle;


    public int getPill() {
           return pill;
       }

       public void setPill(int pill) {
           this.pill = pill;
       }

       public int getPowerpill() {
           return powerpill;
       }

       public void setPowerpill(int powerpill) {
           this.powerpill = powerpill;
       }

       public double getPoints() {
           return points;
       }

       public void setPoints(double points) {
           this.points = points;
       }

       public int getEmpty() {
           return empty;
       }

       public void setEmpty(int empty) {
           this.empty = empty;
       }

       public int getGhost() {
           return ghost;
       }

       public void setGhost(int ghost) {
           this.ghost = ghost;
       }




       public CollectorG(Pheromone[][] phero, Node initial,
                         int distPac,
                         Random rand,
                         int max_dist,
                         double q0,
                         boolean edibleGhost,
                         double fac,
                         GameStateInterface gs,
                         double phi,
                         double alfa,
                         boolean middle)
       {
               super.pheromone = phero;
               super.gs = gs;
               super.last = initial;
               super.distance = distPac;
               super.nodes = new ArrayList<SimpleNode>();
               super.r = rand;
               super.MAX_DISTANCE = max_dist;
               super.Q0 = q0;
               super.FACTOR_SEC = fac;
               super.alfa = alfa;
               super.phi = phi;
               this.setEdibleGhost(edibleGhost);
               this.pill = 0;
               this.powerpill=0;
               this.points = 0;
               this.empty = 0;
               this.ghost = 0;
               this.middle = middle;

       }
       public void execute( GameStateInterface gs, Ghosts g)
       {

           this.nodes.add(new SimpleNode(g.current,0,0,0,false,false,gs));
           while (!stopCondition(gs))
           {
               move( gs, 0);
           }

       }

       public void move(GameStateInterface gs, int i)
       {
           Node nodeUpdate = gs.getMaze().getNode(last.x,last.y);
           collectFood(nodeUpdate, gs);
           int peligrosidad = 0;
           boolean edibleGhost = this.existsEdibleGhost(nodeUpdate, gs,powerpill);
           this.dead = isDead(nodeUpdate, gs);
           this.nodes.add(new SimpleNode(last,super.calculateConnectivity(last), (int)distance, peligrosidad, dead, edibleGhost,this.points,false,gs));
           this.pheromoneEvaporation(last);
           Node aux = chooseNext(nodeUpdate, i);
           if (aux == null)//No ghost but Exist a loop
           {
               this.loop = true;
           }
           else //No ghost
           {
               this.last = aux;
           }
           this.distance += 1;
       }

     private boolean isDead(Node node, GameStateInterface gs)
    {
        double aux = agentOverlapDistance+1;
        double peligrosidad = gs.getMaze().dist(node,gs.getPacman().current);
        double time = (this.distance +aux);
        return (peligrosidad > time );
    }
       public Node chooseNextBest(Node n, int ind)
       {
           Node next = null;

           ArrayList<Node> adjacents =  possibleDir(n);
           ArrayList <Double> probability = new ArrayList <Double>();


           int best = 0;
           for (int i = 0; i < adjacents.size(); i++)
           {
               SimpleNode snode = new SimpleNode(adjacents.get(i), calculateConnectivity(adjacents.get(i)),(int) distance, 0, false, false,gs);
               probability.add(computeRuleTranstion(adjacents.get(i), ind));
               if (computeRuleTranstion(adjacents.get(i), ind) >=
                       computeRuleTranstion(adjacents.get(best), ind))
               {
                   best = i;
                   next = adjacents.get(best);
               }
           }
           return next;
       }



       public Node chooseNext(Node n, int ind)
       {
           Node next = null;
           ArrayList<Node> adjacents = possibleDir(n);
           if (adjacents.size() == 1)
               next = adjacents.get(0);
           else
           {
               ArrayList <Double> probability = new ArrayList <Double>();

               double Q = r.nextDouble();

               if (Q > Q0)
                   return (chooseNextBest(n, ind));

               double sum = 0;
               for (int i = 0; i < adjacents.size(); i++)
               {
                   SimpleNode snode = new SimpleNode(adjacents.get(i), calculateConnectivity(adjacents.get(i)), (int)distance, 0, false, false,gs);
                   probability.add(computeRuleTranstion(adjacents.get(i), ind));
                   sum += computeRuleTranstion(adjacents.get(i), ind);
               }


               for (int i = 0; i < probability.size(); i++)
               {
                   double aux = probability.get(i);
                   probability.set(i, aux/sum) ;
               }

               double ran = r.nextDouble();
               //Select the next Node
               sum = 0;
               for (int i = 0; i < probability.size(); i++)
               {
                   sum += probability.get(i);
                   if (sum > ran)
                   {
                       next = adjacents.get(i);
                       break;
                   }
               }
           }
           return next;
       }

       public double heuristic(Node n, GameStateInterface gs)
       {

           double res = 0;
           if(!edibleGhost)
                res += 1.0/gs.getMaze().dist(n,gs.getPacman().current);
           else
                res += gs.getMaze().dist(n,gs.getPacman().current);
           return res;
       }
       public double computeRuleTranstion(Node n, int ind)
       {
           double deseability = 0;
           try{
           if(pheromone[n.x][n.y]==null)
               System.out.print("");
           deseability += pheromone[n.x][n.y].getValue()[ind];
           deseability *= (1+heuristic(n, gs));
           }catch(ArrayIndexOutOfBoundsException e){
               System.out.println("erro");
           }
           return deseability;
       }
       public void pheromoneEvaporation(Node node)
       {

           //PHEROMONE 0 --> FOOD
           double Va = pheromone[node.x][node.y].getValue()[0];
           double Vi = 1;
           pheromone[node.x][node.y].getValue()[0] = (1-this.phi)*Va + phi*(Vi);

       }
       public void update(GameStateInterface gs)
       {
           for (int j = 0; j < this.nodes.size(); j++)
           {
               SimpleNode s = this.nodes.get(j);
               Node n = gs.getMaze().getNode(s.getX(),s.getY());
               double val = pheromone[n.x][n.y].getValue()[0];
               pheromone[n.x][n.y].getValue()[0] = (1 - alfa) *val + (this.points+1)* alfa;
           }
       }
       public void collectFood(Node node, GameStateInterface gameState)
       {
           if(!edibleGhost)
            this.points = 1.0/(gameState.getMaze().dist(node,gameState.getPacman().current));
           else
               this.points = (gameState.getMaze().dist(node,gameState.getPacman().current));


       }

       private boolean stopCondition(GameStateInterface gameState)
       {
           int last = this.nodes.size() - 1;
           if(!middle )
           return ( gameState.getMaze().dist(this.last, gameState.getPacman().current) == agentOverlapDistance ||
                   this.loop);
           else
               return ( gameState.getMaze().dist(this.last, gameState.getPacman().current) <= distance ||
                   this.loop || this.dead);

       }


    public boolean isEdibleGhost() {
        return edibleGhost;
    }

    public void setEdibleGhost(boolean edibleGhost) {
        this.edibleGhost = edibleGhost;
    }
}
