import core.GameStateInterface;
import core.Node;

/**
 * Created by IntelliJ IDEA.
 * User: Emilio
 * Date: 23-jul-2010
 * Time: 12:08:55
 * To change this template use File | Settings | File Templates.
 */
public class SimpleNode
{
    private double points = 0;
    private double  distfromghost = 0;//new int [4];
    public static enum typeOfNode {Pill,PowerPill,Empty};
    private int connectivty = 0;
    // distance between this node and Ms. Pacman.
    private int distance = 0;
    private String type;
    private boolean existGhost = false;
    private boolean existEdibleGhost = false;
    private boolean tunnel;
    private int x;
    private int y;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public double getPoints() {
        return points;
    }

    public void setPoints(double points) {
        this.points = points;
    }

    public int getConnectivty() {
        return connectivty;
    }

    public void setConnectivty(int connectivty) {
        this.connectivty = connectivty;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public boolean isTunnel() {
        return tunnel;
    }

    public void setTunnel(boolean tunnel) {
        this.tunnel = tunnel;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public double getDistfromghost() {
        return distfromghost;
    }

    public void setDistfromghost(double distfromghost) {
        this.distfromghost = distfromghost;
    }

    public SimpleNode(Node n, int nodeConect, int distan, double distfromghost, boolean ghost, boolean edibleGhost, double points, boolean tunnel, GameStateInterface gs)
    {
        x = n.x;
        y = n.y;
        
        this.distance = distan;
        this.distfromghost = distfromghost;
        existEdibleGhost = edibleGhost;
        existGhost = ghost;
        connectivty = nodeConect;
        this.points = points;
        this.tunnel = tunnel;
        if (n.pillIndex != -1 && gs.getPills().get(n.pillIndex))
            this.type = typeOfNode.Pill.toString();
        else if (n.powerIndex != -1 &&  gs.getPowers().get(n.powerIndex))
            this.type = typeOfNode.PowerPill.toString();
        else
            this.type = typeOfNode.Empty.toString();



    }
    public SimpleNode(Node n, int nodeConect, int distan, double distfromghost, boolean ghost, boolean edibleGhost, GameStateInterface gs)
    {
        x = n.x;
        y = n.y;
        this.distance = distan;
        this.distfromghost = distfromghost;
        existEdibleGhost = edibleGhost;
        existGhost = ghost;
        connectivty = nodeConect;
        if (n.pillIndex != -1 && gs.getPills().get(n.pillIndex))
            this.type = typeOfNode.Pill.toString();
        else if (n.powerIndex != -1 &&  gs.getPowers().get(n.powerIndex))
            this.type = typeOfNode.PowerPill.toString();
        else
            this.type = typeOfNode.Empty.toString();

    }
    public boolean IsSame(Node node)
    {
        if (node.x == x && node.y == y)
        {
            return true;
        }
        return false;
    }
    public static Node getNode(SimpleNode s)
    {
        return new Node(s.x,s.y);
    }
    public String toString()
    {
        return ("{" + x + "," + y + "}");
    }
}

