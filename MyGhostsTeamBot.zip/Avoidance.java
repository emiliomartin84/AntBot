/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import core.GameStateInterface;
import core.Ghosts;
import core.Node;
import core.maze.MazeInterface;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Emilio
 */
@SuppressWarnings("unchecked")

public class Avoidance extends Ant{

    private int min_dist_ghost;
    private int conectivity;
    private int points=0;
    private Ghosts closestGhost;
    private double dist_from_ghost = Double.MAX_VALUE;
    public Avoidance(Pheromone[][] phero,Node initial, int distPac, Random rand, int max_distance, GameStateInterface gs, double q0, double fac, double phi, double alfa)
    {
        super.pheromone = phero;
        super.gs = gs;
        super.last = initial;
        super.distance = distPac;
        super.nodes = new ArrayList<SimpleNode>();
        super.r = rand;
        super.MAX_DISTANCE = max_distance;
        //MAX_POINT = max_point;
        super.Q0 = q0;
        super.FACTOR_SEC = fac;
        super.alfa = alfa;
        super.phi = phi;
        this.closestGhost = new Ghosts();
    }

    public void execute( GameStateInterface gs)
    {

        Color c = new Color(r.nextInt(256),
                    r.nextInt(256),
                    r.nextInt(256),
                    200);
        this.nodes.add(new SimpleNode(gs.getPacman().current,0,0,0,false,false,gs));
        while (!stopCondition(gs))
        {
            move( gs, 1, c);
        }
    }

    private boolean stopCondition(GameStateInterface gameState)
    {
        int last = this.nodes.size() - 1;
        if (last != 0 &&
                this.distance >= this.MAX_DISTANCE &&
                (this.nodes.get(last)).getConnectivty() == 2 && !this.dead && !loop)
            return false;
        return (
                this.distance >= this.MAX_DISTANCE ||
                        this.loop ||
                        this.dead ||
                        this.powerpill >0
                        )
                ;
    }

    private boolean isDead(Node node, GameStateInterface gs)
    {
        double aux = agentOverlapDistance+1;

        if (this.powerpill != 0)
            return false;
        double peligrosidad = closestGhostDistance(node,this.closestGhost,gs);

        double time = (this.distance +aux);
        if (isCommingOther(this.closestGhost) && peligrosidad == 0  )
            return true;
        return (peligrosidad > 0 && peligrosidad < time
                && this.powerpill == 0 && pill != gs.getPills().cardinality() && isCommingOther(this.closestGhost));

    }
     public void collectFood(Node node, GameStateInterface gameState)
    {
        //double peligrosidad = this.peligrosidad(node, gameState);
        double pillsLeft = gameState.getPills().cardinality() - this.pill;
        double pillFactor = pillsLeft / (double) gameState.getPills().cardinality();

        if (node.pillIndex!= -1 && gameState.getPills().get(node.pillIndex))
        {
            this.pill++;
            this.points += 1;
        }
        if (node.powerIndex!= -1 && gameState.getPowers().get(node.powerIndex))
        {
            this.powerpill++;
        }

    }
    public void move( GameStateInterface gs, int i, Color c)
    {

        this.gs = gs;
        Node nodeUpdate = gs.getMaze().getNode(last.x,last.y);
        collectFood(nodeUpdate, gs);
        this.min_dist_ghost = minDistGhostFPacman(gs);

        this.closestGhost =  closestGhost(nodeUpdate, gs);
        this.dist_from_ghost = closestGhostDistance(nodeUpdate,closestGhost,gs);
        boolean edibleGhost = this.existsEdibleGhost(nodeUpdate, gs,powerpill);
        boolean ghost = this.existsGhost(nodeUpdate, gs);
        this.dead = isDead(nodeUpdate, gs);
        int conect = calculateConnectivity(last);
        if(conect >2)
        this.conectivity += conect;

        this.nodes.add(new SimpleNode(last,conect, distance, this.dist_from_ghost, ghost, edibleGhost,0,isTunnel(nodeUpdate,gs),gs));
        //An ant is died in a node if some ghost is closest of this node and dont eat any power pill.
        this.pheromoneEvaporation(last);
        Node aux = chooseNext(nodeUpdate, i);
		if (aux == null)//No ghost but Exist a loop
		{
			this.loop = true;
		}
		else //No ghost
		{
			//Calculate direction ant.
			List<Node> posibleDir = this.last.adj;// PossibleDirections;
			this.last = aux;
    	}
		this.distance += 1;
        //nodeUpdate.col = c;
    }

    public boolean isTunnel(Node n, GameStateInterface gameState)
    {
        boolean res = false;
        int left = (n.x - 1) %  gameState.getMaze().getWidth();
        int rigth = (n.x + 1) %  gameState.getMaze().getWidth();
        Node nLeft = gameState.getMaze().getNode(left,n.y);
        Node nRigth = gameState.getMaze().getNode(rigth,n.y);

        if ( (nLeft != null && n.x < nLeft.x)   || (nRigth != null && n.x > nRigth.x) )
            res = true;
        res = false;
        return res;
    }

        public void update(GameStateInterface gs)
        {
            double pel = 0;
            for (int j = 0; j < this.nodes.size(); j++)
            {
                double fac = 1.0 / ( (j+1) * (j+1) );
                pel += this.nodes.get(j).getDistfromghost();//*fac;
            }
            for (int j = 0; j < this.nodes.size(); j++)
            {
                SimpleNode s = this.nodes.get(j);

                double val = pheromone[s.getX()][s.getY()].getValue()[1];
                pheromone[s.getX()][s.getY()].getValue()[1] = (1 - alfa) * val + pel * alfa;
            }
        }

    public void pheromoneEvaporation(Node node)
    {
        double Va = pheromone[node.x][node.y].getValue()[1];
        double Vi = 1;
        pheromone[node.x][node.y].getValue()[1] =(1-this.phi)*Va + phi*(Vi);
    }

    public Node chooseNext(Node n, int ind)
    {
        Node next = null;
        ArrayList<Node> adjacents = possibleDir(n);
        if (adjacents.size() == 1)
            next = adjacents.get(0);
        else
        {
            ArrayList <Double> probability = new ArrayList <Double>();

            double Q = r.nextDouble();

            if (Q > Q0)
                return (chooseNextBest(n, ind));

            double sum = 0;
            for (int i = 0; i < adjacents.size(); i++)
            {
                SimpleNode snode = new SimpleNode(adjacents.get(i), calculateConnectivity(adjacents.get(i)), distance, 0, false, false,gs);
                probability.add(computeRuleTranstion(adjacents.get(i), ind));
                sum += computeRuleTranstion(adjacents.get(i), ind);
            }


            for (int i = 0; i < probability.size(); i++)
            {
                double aux = probability.get(i);
                probability.set(i, aux/sum) ;
            }

            double ran = r.nextDouble();
            //Select the next Node
            sum = 0;
            for (int i = 0; i < probability.size(); i++)
            {
                sum += probability.get(i);
                if (sum > ran)
                {
                    next = adjacents.get(i);
                    break;
                }
            }
        }
        return next;
    }

    public Node chooseNextBest(Node n, int ind)
    {
        Node next = null;

        ArrayList<Node> adjacents =  possibleDir(n);
        ArrayList <Double> probability = new ArrayList <Double>();


        int best = 0;
        for (int i = 0; i < adjacents.size(); i++)
        {

            probability.add(computeRuleTranstion(adjacents.get(i), ind));
            if (computeRuleTranstion(adjacents.get(i), ind) >=
                    computeRuleTranstion(adjacents.get(best), ind))
            {
                best = i;
                next = adjacents.get(best);
            }
        }
        return next;
    }

    public double heuristic(Node n)
    {
        double res = 0;

        res +=  closestGhostDistance(n,closestGhost,this.gs);
        res += calculateConnectivity(n);
        return res;
    }

    public static Node getNode ( Node from, int direction, MazeInterface maze)
    {
        Node res = null;
        int x = (from.x + dx[direction] + maze.getWidth()) % maze.getWidth();
        int y = (from.y + dy[direction] + maze.getHeight()) % maze.getHeight();

        res = maze.getNode(x,y);
        return res;
    }



    public boolean isCommingOther( Ghosts g)
    {
        if(g!=null && g.previous !=null){
            int distancePrev =  gs.getMaze().dist(g.previous,last);
            int distanceAct = gs.getMaze().dist(g.current,last);
            return distanceAct<distancePrev;

        }else
            return false;

    }
    public double computeRuleTranstion(Node n, int ind)
    {
        double deseability = 0;
        deseability += pheromone[n.x][n.y].getValue()[ind];
        deseability += heuristic(n);
        return deseability;
    }

    private int minDistGhostFPacman(GameStateInterface gameState)
    {
        Node position = gameState.getPacman().current;
        int distFromGhost=10000;
        Ghosts ghost;
        for (  Ghosts g: gameState.getGhosts() )
        {
            int distance = gameState.getMaze().dist(g.current,position);
            if (distance < distFromGhost && !g.edible() && !g.returning())
            {
                distFromGhost = distance;

            }
        }
        return distFromGhost;
    }
}
