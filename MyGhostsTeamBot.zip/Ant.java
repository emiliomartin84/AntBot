/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


import core.Constants;
import core.GameStateInterface;
import core.Ghosts;
import core.Node;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 *
 * @author Emilio
 */
public abstract class Ant implements Constants {

    protected GameStateInterface gs;
    protected  Pheromone[][] pheromone;
    protected boolean loop = false;
    public boolean dead = false;
    protected double Q0 = 0;
    protected double phi=0;
    protected double FACTOR_SEC = 0;
    protected double alfa = 0;

    protected int powerpill;
    public int pill;
    protected Node last;
    protected List<SimpleNode> nodes;
    protected Random r;
    protected int MAX_DISTANCE;

    public GameStateInterface getGs() {
        return gs;
    }

    public void setGs(GameStateInterface gs) {
        this.gs = gs;
    }

    public boolean isLoop() {
        return loop;
    }

    public void setLoop(boolean loop) {
        this.loop = loop;
    }

    public boolean isDead() {
        return dead;
    }

    public void setDead(boolean dead) {
        this.dead = dead;
    }

    public double getQ0() {
        return Q0;
    }

    public void setQ0(double q0) {
        Q0 = q0;
    }

    public double getPhi() {
        return phi;
    }

    public void setPhi(double phi) {
        this.phi = phi;
    }

    public double getFACTOR_SEC() {
        return FACTOR_SEC;
    }

    public void setFACTOR_SEC(double FACTOR_SEC) {
        this.FACTOR_SEC = FACTOR_SEC;
    }

    public double getAlfa() {
        return alfa;
    }

    public void setAlfa(double alfa) {
        this.alfa = alfa;
    }

    public Node getLast() {
        return last;
    }

    public void setLast(Node last) {
        this.last = last;
    }

    public List<SimpleNode> getNodes() {
        return nodes;
    }

    public void setNodes(List<SimpleNode> nodes) {
        this.nodes = nodes;
    }

    public Random getR() {
        return r;
    }

    public void setR(Random r) {
        this.r = r;
    }

    public int getMAX_DISTANCE() {
        return MAX_DISTANCE;
    }

    public void setMAX_DISTANCE(int MAX_DISTANCE) {
        this.MAX_DISTANCE = MAX_DISTANCE;
    }

    public int getDistance() {
        return distance;
    }

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public int distance;

    public boolean existsGhost(Node position, GameStateInterface gameState)
    {
        boolean res = false;
        for (Ghosts ghost : gs.getGhosts())
        {
            //Console.WriteLine(ghost.RemainingFlee);
            if (!ghost.edible() &&
                ghost.current.equals(position) &&
                !ghost.returning())
            {
                res = true;
                break;
            }
        }
        return res;
    }
 public boolean isComming(GameStateInterface gs,Ghosts g, Node last)
    {
        if(g.previous !=null){

            int distancePrev =  gs.getMaze().dist(g.previous,last);
            int distanceAct = gs.getMaze().dist(g.current,last);
            if(distanceAct < distancePrev)
                return true;
            else
                return false;
        }else
            return false;

    }
    public boolean existsEdibleGhost(Node position, GameStateInterface gameState,int powerpill)
    {
        boolean res = false;
        for (Ghosts ghost : gs.getGhosts())
        {
            
            if ( ( (powerpill > 0)|| ghost.edible()) &&
                    gameState.getMaze().dist(position,ghost.current) == agentOverlapDistance &&
                !ghost.returning()&& this.isComming(gameState,ghost, position))
            {
                res = true;
                break;
            }
            //Set min distance.
        }
        return res;
    }
    protected int calculateConnectivity(Node node)
    {
        return  node.adj.size();
    }

       public ArrayList<Node> possibleDir(Node node)
    {
        ArrayList<Node> res = new ArrayList<Node>();

        for(int i = 0;i<node.adj.size();i++)
        {
            res.add(node.adj.get(i));
        }
        for(int i =0;i<res.size();i++){
            if( hasVisited (res.get(i)))
            {
                res.remove(i);
                i--;
            }
        }
        return res;
    }

    public Ghosts closestGhost (Node node, GameStateInterface gameState)
    {
        int distFromGhost= Integer.MAX_VALUE;
        Ghosts ghost=null;
        for (  Ghosts g: gameState.getGhosts() )
        {
            int distance = gameState.getMaze().dist(g.current,node);
            int distanceA = distance;
            if(g.previous!=null)
                 distanceA= gameState.getMaze().dist(g.previous,node);
            if (distance < distFromGhost && !g.edible() && !g.returning() )
            {
                distFromGhost = distance;
                ghost = g;
            }
        }
        return ghost;
    }

    public int closestGhostDistance(Node node, Ghosts g,   GameStateInterface gameState)
    {
        if(g !=null && g.current!=null)
        return  gameState.getMaze().dist(g.current,node);
        else
            return 10000;
    }

    public int closestEdibleGhost (Node node, GameStateInterface gameState)
    {
        int distFromGhost=10000;
        Ghosts ghost;
        for (  Ghosts g: gameState.getGhosts() )
        {
            int distance = gameState.getMaze().dist(g.current,node);
            if (distance < distFromGhost && g.edible() && !g.returning() && isComming(gameState,g,node))
            {
                distFromGhost = distance;
            }
        }
        return distFromGhost;
    }
    
    public boolean hasVisited(Node n)
    {
        boolean res = false;
        for(int i = 0;i<this.nodes.size();i++)
        {
            SimpleNode aux = nodes.get(i);
            if (aux.IsSame(n)){
                res = true;
                break;
            }
        }
        return res;
    }
    
}
