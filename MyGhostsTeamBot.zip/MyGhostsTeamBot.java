import competition.GhostsController;
import core.Constants;
import core.GameStateInterface;
import core.Ghosts;
import core.Node;
import core.maze.MazeInterface;
import core.utilities.Utilities;
import core.visuals.GameStateView;
import core.visuals.JEasyFrame;

import java.awt.*;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Vector;

/**
 * Created by IntelliJ IDEA.
 * User: Emilio
 * Date: 23-abr-2011
 * Time: 22:48:49
 * To change this template use File | Settings | File Templates.
 */
public class MyGhostsTeamBot implements GhostsController {
    private Vector<Avoidance> antsA;
    private boolean debugA = !true;
    private int res;

    private boolean debug = false;
    private boolean visual = !true;//true;//true; //Show the best ants in the maze
    private boolean rules = !true;

    int lives;
    int currentLevel =-1;
    Color cBectC = new Color (0, 255,0,25);
    Color cBectA = new Color (255,0,0,25);
    private int aDead = 0;
    private int cDead = 0;
    private int bestC = 0;
    private int bestA = 0;
    private boolean allDeadAvoidance = false;
    private boolean allDeadCollecter = false;
    Vector<CollectorG> antsC;
    //Vector<Avoidance> antsA;

    //30-22-7-0.27-0.97-0.71-0.72-0.09-0.03-0.78-0.56
    private Random random;
    private java.util.List<Object> backup;
    private int maxAntsC;
    private double edible_ghost = 70;
    private int MIN_DISTANCE = 0;
    private double phi0 = 0.5;
    private double phi1 = 0.5;
    private double alfa0 = 0.5;
    private double alfa1 = 0.5;
    //////Max points of ants Collecter.
    private double FACT_SEC_T0 = 0.0;
    private double FACT_SEC_T1 = 0.0;
    private double q0_T0 = 0.5;
    private double q0_T1 = 0.95;
    private int MAX_DISTANCE_T0 = 100;
    private int MAX_DISTANCE_T1 = 100;
    private int maxAntsA;
    private  Pheromone[][] pheromones;
    private GameStateView gsv;
    private JEasyFrame jframe;
    private int[] dirs;
    private final Color [] colors = {  new Color (255,0,0,25),
                                       new Color (255,184,222,25),
                                       new Color (255,184,71,25),
                                       new Color (0,255,222,25),

                                       };


    public MyGhostsTeamBot() {
        this.dirs = new int [4];
        this.lives = -1;
        double [] par = {18,84,14,0.71,0.92,0.18,0.84,0.49,0.45,0.16,0.73,98,115,19};
        setParams(par);
        backup();
    }


    public void backup(){
        backup = new ArrayList();
        random = new Random();
        backup.add(maxAntsC); //Max ants
        backup.add(edible_ghost);
        backup.add(MIN_DISTANCE);//MIN_DISTANCE
        backup.add(phi0); //Phi0
        backup.add(phi1); //Phi1
        backup.add(alfa0); //alfa0
        backup.add(alfa1); //alfa1
        backup.add(FACT_SEC_T0);
        backup.add(FACT_SEC_T1);
        backup.add(q0_T0);
        backup.add(q0_T1);
       backup.add(MAX_DISTANCE_T0);
        backup.add(MAX_DISTANCE_T1);
        backup.add(maxAntsA);
    }
    public MyGhostsTeamBot(double[] params) {
        this.dirs = new int [4];
        this.lives = -1;
        random = new Random();
        backup = new ArrayList();
        random = new Random();
        setParams(params);
        backup();
    }

    public void setParams(double [] params)
    {
        maxAntsC= (int) params[0]; //Max ants
        edible_ghost=params[1];
        MIN_DISTANCE= (int) params[2];//MIN_DISTANCE
        phi0=params[3]; //Phi0
        phi1=params[4]; //Phi1
        alfa0=params[5]; //alfa0
        alfa1=params[6]; //alfa1
        FACT_SEC_T0=params[7];
        FACT_SEC_T1=params[8];
        q0_T0=params[9];
        q0_T1=params[10];
        MAX_DISTANCE_T0 = (int) params[11];
        MAX_DISTANCE_T1 = (int) params[12];
        maxAntsA = (int) params[13];

    }


     public void setVisual(GameStateView gs,JEasyFrame jf)
    {
        this.jframe = jf;
        this.gsv = gs;

    }

    public void reset()
    {

        //Max distance of ants avoidance.
        allDeadAvoidance = false;
        allDeadCollecter = false;
        maxAntsC = (Integer)backup.get(0);            //Max ants
        edible_ghost = (Double)backup.get(1);       //Edible ghost
        MIN_DISTANCE = (Integer)backup.get(2);       //MIN_DISTANCE
        phi0 = (Double)backup.get(3);            //Phi0
        phi1 = (Double)backup.get(4);            //Phi1
        alfa0 = (Double)backup.get(5);           //ALFA_T0
        alfa1 = (Double)backup.get(6);           //ALFA_T1
        FACT_SEC_T0 = (Double)backup.get(7);     //FACT_SEC_T0
        FACT_SEC_T1 = (Double)backup.get(8);     //FACT_SEC_T1
        q0_T0 = (Double)backup.get(9);           //Q0_T0
        q0_T1 = (Double)backup.get(10);          //Q0_T1
        MAX_DISTANCE_T0 = (Integer)backup.get(11);
        MAX_DISTANCE_T1 = (Integer)backup.get(12);;
        maxAntsA = (Integer)backup.get(13);;
    }

    private void initPheromones( GameStateInterface gs)
    {

        Node [][] na =  gs.getMaze().getNode2DArray();
        pheromones = new Pheromone[na.length][];

        for(int i =0;i<pheromones.length;i++)
        {
            pheromones[i] = new Pheromone[na[i].length];
            for(int j =0;j<pheromones[i].length;j++){
                Node aux = na[i][j];
                if(aux!=null)
                    pheromones[i][j] = new Pheromone(aux.x,aux.y,2,1);
            }
        }
    }

    public int[] getActions(GameStateInterface gs)  {
        if(gs.getLevel()!=currentLevel){
            initPheromones(gs);
            this.currentLevel = gs.getLevel();
        }
        if(lives != gs.getLivesRemaining())
        {
            lives = gs.getLivesRemaining();
            reset();
        }
        Node nodepac = gs.getPacman().current;
        simulatePac(gs,maxAntsA);
        for (int i = 0; i < gs.getGhosts().length; i++) {
            Ghosts gh = gs.getGhosts()[i];
            dirs[i] = getAction(gs,gh,i);

            /*if(gs.gameTicks%2==0)
                dirs[i] = Constants.LEFT;
            else
                dirs[i] = Constants.RIGHT;*/
        }

        return dirs;
    }


    public int getAction(GameStateInterface gs, Ghosts ghost, int z) {


        Node next=null;
        //gs  = (GameState)gas.copy();
        Node ghostNode = ghost.current;

        sendAnt(ghostNode,maxAntsC,gs,ghost, z);
        updatePheromone(gs,z);
        updateDistances ();
        SimpleNode no;
        if(antsC.size() <= 1 )           {
            return Constants.NEUTRAL;
        }

        if(antsC.get(bestC).getNodes().size() >1){
            no = antsC.get(bestC).getNodes().get(1);
            next = gs.getMaze().getNode(no.getX(), no.getY());
            res = Utilities.getWrappedDirection(ghostNode, next, gs.getMaze());//,gs.getMaze());
            if (visual)
        {

            paintBest(gs, colors[z]);
            this.gsv.repaint();
            this.jframe.repaint();
            BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
            try {

                buf.readLine();
            } catch (IOException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }
            return res;
        }
        return Constants.NEUTRAL;
    }

    private void updateDistances ()
    {
         if (this.allDeadCollecter)
            if(this.MAX_DISTANCE_T0 < (Integer)backup.get(11))
                this.MAX_DISTANCE_T0 = this.MAX_DISTANCE_T0 + 1;
            else
            {
                if (this.MAX_DISTANCE_T0 > (Integer)backup.get(11))
                    this.MAX_DISTANCE_T0 = this.MAX_DISTANCE_T0 - 1;
                else
                    this.MAX_DISTANCE_T0 = this.MAX_DISTANCE_T0 + 1;
            }
        if (this.allDeadAvoidance) //All ants are died
        {
            if (this.MAX_DISTANCE_T1 > (Integer)backup.get(12))
                this.MAX_DISTANCE_T1 = this.MAX_DISTANCE_T1 / 2;
            else if (MAX_DISTANCE_T1 > (Integer)backup.get(12)/2)
                this.MAX_DISTANCE_T1 = this.MAX_DISTANCE_T1 - 1;
        }
        else
        {
            if (this.MAX_DISTANCE_T1 < (Integer)backup.get(12)/2)
                this.MAX_DISTANCE_T1 *= 2;
            else if (MAX_DISTANCE_T1 < (Integer)backup.get(12))
                this.MAX_DISTANCE_T1 += 1;
        }

    }

    private void simulatePac (GameStateInterface gs, int maxAnts)
    {
        ArrayList<Node> possible = adjacents(gs.getPacman().current,gs.getMaze());
        antsA = new Vector<Avoidance>();
        for(int i=0;i<maxAnts;i++)
        {
            int aux =  (i % possible.size());
            Avoidance a = new Avoidance(this.pheromones,possible.get(aux),1,random,MAX_DISTANCE_T1,gs,q0_T1,FACT_SEC_T1,phi1,alfa1);
            a.execute(gs);
            antsA.add(a);
            if(a.dead)
                aDead++;
        }
        double[] pel = new double[antsA.size()];

        for (int i = 0; i < antsA.size(); i++)
        {
            Color c = new Color (random.nextInt(256),
                    random.nextInt(256),
                    random.nextInt(256),
                    125);
            Ghosts ga = antsA.get(i).closestGhost(gs.getPacman().current,gs);
            int closestF = antsA.get(i).closestGhostDistance(gs.getPacman().current,ga,gs);
            for (int j = 0; j < antsA.get(i).getNodes().size(); j++)
            {
                SimpleNode s = antsA.get(i).getNodes().get(j);
                double fac = 1.0 / (Math.pow((j + 1),   2) );
                Node n = gs.getMaze().getNode(s.getX(), s.getY());
                double val = pheromones[s.getX()][s.getY()].getValue()[0];
                pel[i] += antsA.get(i).getNodes().get(j).getDistfromghost() * fac + val * FACT_SEC_T1 * fac;
                if (antsA.get(i).getNodes().get(j).getType().toString() == SimpleNode.typeOfNode.PowerPill.toString()
                        && numEdibleGhost(gs)==0 )
                    pel[i] *= 100 ;
                if (antsA.get(i).pill == gs.getPills().cardinality())
                {
                    pel[i] *=100000;
                }
            }
            if (debugA)
            {
                for(int j = 0; j < antsA.get(i).getNodes().size(); j++)
                {
                    SimpleNode s = antsA.get(i).getNodes().get(j);
                    Node n = gs.getMaze().getNode(s.getX(), s.getY());
                    n.col = c;

                }
                this.gsv.repaint();
                this.jframe.repaint();
                BufferedReader br = new BufferedReader(new InputStreamReader(System.in) );
                try {
                    br.readLine();
                } catch (IOException e) {
                    e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                }
            }
        }

        for (int i = 0; i < antsA.size(); i++)
        {
            if (!allDeadAvoidance && !antsA.get(i).isDead()){
                pel[i] *= 10;
                antsA.get(i).update(gs);
            }
            if (allDeadAvoidance)
                pel[i] = antsA.get(i).distance;
            if (pel[bestA] < pel[i])
                bestA = i;
        }


        if(antsA.size() > 0 )//&& avoid(gs) )
            //(antsA.get(bestA)).update(gs);
        if (antsA.size() == 0)
            allDeadCollecter = true;


    }

    public int numEdibleGhost (GameStateInterface gs)
    {
        int res = 0;
        for (  Ghosts g: gs.getGhosts() )
        {
            if (g.edible() && !g.returning() )
            {
                res++;
            }
        }
        return res;
    }
    private void sendAnt(Node initial, int numAnts, GameStateInterface gs, Ghosts g, int id)
    {

        antsC = new Vector<CollectorG>();
        ArrayList<Node> possible = adjacents(initial,gs.getMaze(),g);
        this.cDead = 0;
        this.aDead = 0;
        for(int i=0; i<numAnts;i++)
        {
            int aux =  (i % possible.size());
            CollectorG c;

            c= new CollectorG(this.pheromones,possible.get(aux),1, random, MAX_DISTANCE_T0, (q0_T0)+0.1*id, g.edible(), FACT_SEC_T0, gs, phi0, alfa0, false);
            /*if (id %2 ==0)
                c= new Collector(this.pheromones,possible.get(aux),1, random, MAX_DISTANCE_T0, q0_T0, g.edible(), FACT_SEC_T0, gs, phi0, alfa0, false);
            else
                c = new Collector(this.pheromones,possible.get(aux),1, random, MAX_DISTANCE_T0, q0_T0, g.edible(), FACT_SEC_T0, gs, phi0, alfa0, true);*/
            //Collector c = new Collector(initial, 0, random, MAX_POINTS_T0, q0_T0, edible_ghost, FACT_SEC_T0, gs, phi0, alfa0);
            c.execute(gs, g);
            antsC.add(c);
            if (c.dead)
                cDead++;

        }

        if (cDead == antsC.size())
            this.allDeadCollecter = true;
        else
            this.allDeadCollecter = false;
    }

    private ArrayList<Node> adjacents(Node n, MazeInterface m, Ghosts g) {

        ArrayList <Node> res = new ArrayList <Node> ();
        int[] dx = {0, 1, 0, -1, 0};
        int[] dy = {-1, 0, 1, 0, 0};
        // then for each proper direction
        for (int i = 0; i < dx.length; i++) {
            if (dx[i] != 0 || dy[i] != 0) {
                Node adj = m.getNode(n.x + dx[i], n.y + dy[i]);
                if (adj != null && g.previous!=adj && g.current!=adj)
                    res.add(adj);
            }
        }
        return res;
    }


    private ArrayList<Node> adjacents(Node n, MazeInterface m) {

        ArrayList <Node> res = new ArrayList <Node> ();
        int[] dx = {0, 1, 0, -1, 0};
        int[] dy = {-1, 0, 1, 0, 0};
        // then for each proper direction
        for (int i = 0; i < dx.length; i++) {
            if (dx[i] != 0 || dy[i] != 0) {
                Node adj = m.getNode(n.x + dx[i], n.y + dy[i]);
                if (adj != null) res.add(adj);
            }
        }
        return res;
    }


    private void  updatePheromone(GameStateInterface gs, int z)
    {
        bestA = 0;
        bestC = 0;
        double pBest = 0;
        double [] points = new double [antsC.size()];
        for(int i= 0;i<antsC.size();i++)
        {
            Color c  = this.colors[z];
            for (int j = 1; j < antsC.get(i).getNodes().size(); j++)
            {

                SimpleNode s = antsC.get(i).getNodes().get(j);
                double fac = 0;
                Node n = gs.getMaze().getNode(s.getX(), s.getY());

                    points[i] += this.pheromones[n.x][n.y].getValue()[1]*((CollectorG)antsC.get(i)).getNodes().get(j).getPoints();
            }
            points[i] /= ((CollectorG)antsC.get(i)).getNodes().size();
            if (debug)
            {
                    for(int j = 0; j < antsC.get(i).getNodes().size(); j++)
                    {
                        SimpleNode s = antsC.get(i).getNodes().get(j);
                        Node n = gs.getMaze().getNode(s.getX(), s.getY());
                        n.col = colors[z];
                    }
                 BufferedReader br = new BufferedReader(new InputStreamReader(System.in) );
                    this.gsv.repaint();

                    try {
                        br.readLine();
                    } catch (IOException e) {
                        e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
                    }


            }
        }
        for (int i = 0; i < antsC.size();i++)
        {
            //if (pel[best] <= pel[i])
            if (points[bestC] < points[i])
                bestC = i;
        }
        if(antsC.size() > 0 ){//&& !avoid(gs))
            (antsC.get(bestC)).update(gs);
            for (int j = 1; j < antsC.get(bestC).getNodes().size(); j++)
            {
                SimpleNode s = antsC.get(bestC).getNodes().get(j);
                double fac = 0;
                Node n = gs.getMaze().getNode(s.getX(), s.getY());
                //points[i] += ((Collector)antsC.get(i)).getNodes().get(j).getPoints() ;// fac + val * FACT_SEC_T0 * fac;
                this.pheromones[n.x][n.y].getValue()[1]=1;

            }

        }
        if (antsC.size() == 0)
            allDeadCollecter = true;


    }

    private void paintBest (GameStateInterface gs, Color color)
    {

        for(int j = 0; j < antsC.get(bestC).getNodes().size(); j++)
        {
            Color c = new Color(color.getRed(),color.getGreen(),color.getBlue(),255);
            SimpleNode s = antsC.get(bestC).getNodes().get(j);
            Node n = gs.getMaze().getNode(s.getX(), s.getY());
            n.col = c;
        }
    }


    public void paintWay (Color color, Node start, Node end, GameStateInterface gs, Ghosts g) throws IOException {
        this.gsv.repaint();
        this.jframe.repaint();
        Node aux = start;
        while(!end.equals(aux)){
            aux = Utilities.getClosest(aux.adj, end,gs.getMaze());
            aux.col = color;
        }
        System.out.println("i "+ g.toString());
        BufferedReader buf = new BufferedReader(new InputStreamReader(System.in));
        buf.readLine();
    }
}
